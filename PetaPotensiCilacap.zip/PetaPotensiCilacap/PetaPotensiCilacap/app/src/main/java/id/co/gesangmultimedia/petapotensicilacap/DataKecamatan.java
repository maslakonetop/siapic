package id.co.gesangmultimedia.petapotensicilacap;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.data.geojson.GeoJsonLayer;

import org.json.JSONException;

import java.io.IOException;


public class DataKecamatan extends AppCompatActivity implements OnMapReadyCallback, AdapterView.OnItemSelectedListener {
    private GoogleMap mMap;
    private GeoJsonLayer geoJsonLayer;
    private Spinner spinner;
    //private GeoJsonLayer geoJsonLayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_kecamatan);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.namakecamatan, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        geoJsonLayer = geoJsonLayer;
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        LatLng cilacap = new LatLng(-7.481717, 108.838529);
        //mMap.addMarker(new MarkerOptions().position(cilacap).title("Cilacap").snippet("Cilacap Bercahaya"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(cilacap));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(10), 1000, null);

        GeoJsonLayer geoJsonLayer = null;
        try {
            geoJsonLayer = new GeoJsonLayer(mMap, R.raw.cilacap,
                    getApplicationContext());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        geoJsonLayer.addLayerToMap();
    }
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String spinSelection = spinner.getSelectedItem().toString();
        if(spinSelection.equals("Adipala")){
            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(new LatLng(-7.659400, 109.149855)).title("Kantor Kecamatan Adipala"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-7.659400, 109.149855), 16));
        }
        else if (spinSelection.equals("Binangun")){
            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(new LatLng(-7.668052, 109.266824)).title("Kantor Kecamatan Binangun"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-7.668052, 109.266824), 16));
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        GeoJsonLayer geoJsonLayer = null;
        try {
            geoJsonLayer = new GeoJsonLayer(mMap, R.raw.cilacap,
                    getApplicationContext());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        geoJsonLayer.addLayerToMap();
    }
}