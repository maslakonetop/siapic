package id.co.gesangmultimedia.petapotensicilacap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.data.geojson.GeoJsonLayer;
import com.google.maps.android.data.geojson.GeoJsonPolygonStyle;

import org.json.JSONException;

import java.io.IOException;

public class PotensiUmum extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private GeoJsonLayer geoJsonLayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_potensi_umum);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        geoJsonLayer = geoJsonLayer;
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        LatLng cilacap = new LatLng(-7.481717, 108.838529);
        //mMap.addMarker(new MarkerOptions().position(cilacap).title("Cilacap").snippet("Cilacap Bercahaya"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(cilacap));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(10), 1000, null);

        GeoJsonLayer geoJsonLayer = null;
        try {
            geoJsonLayer = new GeoJsonLayer(mMap, R.raw.cilacap,
                    getApplicationContext());
            GeoJsonPolygonStyle polygonStyle = geoJsonLayer.getDefaultPolygonStyle();
            polygonStyle.setStrokeColor(ContextCompat.getColor(this, R.color.gray));
            polygonStyle.setFillColor(ContextCompat.getColor(this, R.color.yellow));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        geoJsonLayer.addLayerToMap();

        Marker airpanascipari = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.430953,108.7662454))
        .anchor(0.5f, 0.5f)
        .title("Pemandian Air Panas Cipari")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpariwisata)));

        Marker seratsabutkelapa = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.4056531,108.8025372))
        .anchor(0.5f, 0.5f)
        .title("Serat Sabut Kelapa Wanareja")
        .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconindusti)));

        Marker peternakansapipotong = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.261911, 108.601007))
        .title("Peternakan Sapi Potong Dayeuhluhur")
        .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpeternakan)));

        Marker interbuahpala = googleMap.addMarker(new MarkerOptions()
        .title("Industri Terpadu Pengolahan Buah Pala")
        .position(new LatLng(-7.259467, 108.607142))
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconindusti)));

        Marker sapipotongmajenang = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.258226, 108.683353))
        .title("Peternakan Sapi Potong Majenang")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpeternakan)));

        Marker sapipotongwanareja = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.312470, 108.673625))
        .title("Peternakan Sapi Potong Wanareja")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpeternakan)));

        Marker inpengkelapaterpadu = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.5015207,108.7848592))
        .title("Industri Pengolahan Kelapa Terpadu Kedungreja")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconindusti)));

        Marker ternakkambingkrpucung = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.5537295,108.8129129))
        .title("Peternakan Terpadu Kambing Karangpucung")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpeternakan)));

        Marker gulasemut = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.654652, 109.041271))
        .title("Pabrik Gula Semut Super Jeruklegi")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconindusti)));

        Marker hutanpayau = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.668021,109.0270623))
        .title("Pengembangan Hutan Payau")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpariwisata)));

        Marker ikansidat = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.666796, 109.003658))
        .title("Budidaya Ikan Sidat")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconperikanan)));

        Marker sleko = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.727495, 108.996744))
        .title("Pengembangan Wisata Bahari")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpariwisata)));

        Marker udang = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.662435, 109.260374))
        .title("Industri Terpadu Udang Vaname")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconperikanan)));

        Marker pulaumomongan = googleMap.addMarker(new MarkerOptions()
        .position(new LatLng(-7.712007, 109.387234))
        .title("Pengembangan Wisata Pulau Momongan")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.iconpariwisata)));
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}